<div class="main col-md-9 ml-sm-auto col-lg-10 px-4">
    <h3 class="h3">Crate 1</h3>
    <table>
        <tr>
            <td style="width:70%; padding: 2em;">
               <img src="/assets/img/crates/sc_placeholder.jpg"> 
            </td>
            <td style="padding: 2em; background-color:lightgray;">
                <h3>4,95 $</h3>
                <button type="button" class="btn btn-primary"><i class="fas fa-shopping-cart"></i></button>
            </td>
    </tr>
    <td colspan="2" style="padding: 2em; background-color:lightgray;">
      <p>Crate1<br>
      Contains:<br>
      Info about products:</p>  
    </td>
</table>
</div>
