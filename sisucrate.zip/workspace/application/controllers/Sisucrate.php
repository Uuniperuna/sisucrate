<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sisucrate extends CI_Controller {

    /**
     * Init by calling parent constructor of parent class. Load helpers and model.
     * 
     * @param       -
     * @return      -
     */
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url', 'url_helper'));
        $this->load->model('sisucrate_model');
        $this->load->database();
        $this->load->library('session');
    }


	/**
	 * Index
	 *
	 */
	public function index()
	{
	    $this->load->helper('url');
	    $headerdata['title'] = 'Sisucrate';
	    $logindata['login'] = isset($_SESSION['logged_in']);
	    $this->load->view('sc_header', $headerdata);
	    $this->load->view('sc_navbar', $logindata);
		$this->load->view('sc_index');
		$this->load->view('sc_footer');
	}
	
	public function products()
	{
	    $this->load->helper('url');
	    $headerdata['title'] = 'Products';
	    $logindata['login'] = isset($_SESSION['logged_in']);
		$this->load->view('sc_header', $headerdata);
	    $this->load->view('sc_navbar', $logindata);
		
		$this->load->view('sc_products');
		$this->load->view('sc_footer');
	}	
	
	public function subscriptions()
	{
	    $this->load->helper('url');
	    $headerdata['title'] = 'Subscriptions';
	    $headerdata['subcsritionisivu'] = 1;
	    $logindata['login'] = isset($_SESSION['logged_in']);
		$this->load->view('sc_header', $headerdata);
	    $this->load->view('sc_navbar', $logindata);
		
		$this->load->view('sc_subscriptions');
		$this->load->view('sc_footer');
	}
	
	public function profile()
	{
	    $this->load->helper('url');
	    $this->load->helper('form');
        $this->load->library('form_validation');
	    $headerdata['title'] = 'Profile';
	    $logindata['login'] = isset($_SESSION['logged_in']);
		$emaildata=$_SESSION['user_email'];
		$infodata['infos'] = $this->sisucrate_model->get_info($emaildata);
		
		$this->form_validation->set_rules('etunimi', 'etunimi', 'trim');
		$this->form_validation->set_rules('sukunimi', 'sukunimi', 'trim');
		$this->form_validation->set_rules('aspuh', 'aspuh', 'trim');
		$this->form_validation->set_rules('aspost', 'aspost', 'trim');
		$this->form_validation->set_rules('postitmp', 'postitmp', 'trim');
		$this->form_validation->set_rules('maakunta', 'maakunta', 'trim');
		$this->form_validation->set_rules('postinro', 'postinro', 'trim');
		
        if ($this->form_validation->run() === FALSE) {
		    $headerdata['title'] = 'Profile';
			$this->load->view('sc_header', $headerdata);
			$this->load->view('sc_navbar', $logindata);
			
			$this->load->view('sc_profile', $infodata);
			$this->load->view('sc_footer');
        }
        else {
        	$data = array(
            	'etunimi' => $this->input->post('etunimi'),
            	'sukunimi' => $this->input->post('sukunimi'),
            	'aspuh' => $this->input->post('aspuh'),
            	'aspost' => $this->input->post('aspost'),
            	'postitmp' => $this->input->post('postitmp'),
            	'maakunta' => $this->input->post('maakunta'),
            	'postinro' => $this->input->post('postinro')
            	);
            $this->sisucrate_model->edit_info($data, $emaildata);
            header('Location: '. site_url().'/profile');
        }
	}
	
	public function crates()
	{
	    $this->load->helper('url');
	    $headerdata['title'] = 'Crates';
	    $headerdata['cratesivu'] = 1;
	    $logindata['login'] = isset($_SESSION['logged_in']);
		$this->load->view('sc_header', $headerdata);
	    $this->load->view('sc_navbar', $logindata);
		
		$this->load->view('sc_crates');
		$this->load->view('sc_footer');
	}	
	
	
	
	public function login()
	{
	    $this->load->helper('url');
	    $this->load->helper('form');
        $this->load->library('form_validation');
	    $headerdata['title'] = 'Login';
	    
        $this->form_validation->set_rules('email', 'email', 'trim|required');
        $this->form_validation->set_rules('password', 'password', 'trim|required');
        
        if ($this->form_validation->run() === FALSE) {
		    $headerdata['title'] = 'Register';
			$this->load->view('sc_header', $headerdata);
			$this->load->view('sc_navbar-simple');
			$this->load->view('sc_login');
			$this->load->view('sc_footer');
        }
        else {
        	$data = array(
            	'email' => $this->input->post('email'),
            	'ashash' => $this->input->post('password')
            	);
            	
            if ($this->sisucrate_model->check_user($data, $email)) {
            	$sessiondata = array(
				        'user_email'  => $this->input->post('email'),
				        'logged_in' => TRUE
				);
				$this->session->set_userdata($sessiondata);
            	header('Location: '. site_url());
            } else {
            $errordata['error'] = 'login';
            $this->load->view('sc_header', $headerdata);
			$this->load->view('sc_navbar-simple');
			$this->load->view('sc_alerts', $errordata);
			$this->load->view('sc_login');
			$this->load->view('sc_footer');
            }
        }
	}	
	
	public function logout()
	{
	    $this->load->helper('url');
	    $headerdata['title'] = 'Logout';
		$this->load->view('sc_header', $headerdata);
		unset(
        $_SESSION['email'],
        $_SESSION['ashash'],
        $_SESSION['logged_in']
		);
		header('Location: '. site_url());
	}	
	
	
	private function hash_password($password){
	   return password_hash($password, PASSWORD_BCRYPT);
	}

	
	public function register()
	{
	    $this->load->helper('url');
	    $this->load->helper('form');
        $this->load->library('form_validation');
	    $headerdata['title'] = 'Register';
		
        $this->form_validation->set_rules('email', 'email', 'trim|required');
        $this->form_validation->set_rules('password', 'password', 'trim|required');
        
        if ($this->form_validation->run() === FALSE) {
		    $headerdata['title'] = 'Register';
			$this->load->view('sc_header', $headerdata);
			$this->load->view('sc_navbar-simple');
			$this->load->view('sc_register');
			$this->load->view('sc_footer');
        }
        else {
        	$data = array(
            	'email' => $this->input->post('email'),
            	'ashash' => sha1($this->input->post('password'))
            	);
            $this->sisucrate_model->add_user($data);
            header('Location: '. site_url().'/login');
        }
	}
	
	public function about()
	{
	    $this->load->helper('url');
	    $headerdata['title'] = 'About';
	    $logindata['login'] = isset($_SESSION['logged_in']);
		$this->load->view('sc_header', $headerdata);
	    $this->load->view('sc_navbar', $logindata);
		
		$this->load->view('sc_about');
		$this->load->view('sc_footer');
	}
	
	public function crate1()
	{
		$this->load->helper('url');
	    $headerdata['title'] = 'Crate1';
	    $logindata['login'] = isset($_SESSION['logged_in']);
		$this->load->view('sc_header', $headerdata);
	    $this->load->view('sc_navbar', $logindata);
		
		$this->load->view('sc_crate1');
		$this->load->view('sc_footer');
	}
}
