<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class of learning diary model
 * 
 * @author pl
 */
class Sisucrate_model extends CI_Model {
    
    /**
     * Init by calling parent constructor of parent class. Create db conn.
     * 
     * @param       -
     * @return      -
     */
    public function __constuct() {
        parent::__construct();
        $this->load->database();
    }
   
    /**
     * insert new user to db
     * 
     * @param       array   $data   Array of data
     * @param       array   $asiakasdata   user data
     * @return      boolean
     */
     public function add_user($data = NULL, $asiakasdata = NULL) {
         $this->load->helper('url');
         return $this->db->insert('asiakas', $data);
     }

    /**
     * check user login
     * 
     * @param       
     * @return      boolean
     */     
     public function check_user($data = NULL, $email = NULL) {
         $this->load->helper('url');
         $this->db->where('email', $data['email']);
         $query = $this->db->get('asiakas');
         $hash="";
         foreach ($query->result() as $row)
            {
                $hash = $row->ashash;
            }
        if ($hash==sha1($data['ashash'])) {
            return true;
        } else {
            return false;
        }
     }
     
     
        
    /**
     * edit or insert user information to db
     * 
     * @param       array   $data   Array of data
     * @param       string  $email   email address used
     * @return      boolean
     */
     public function edit_info($data = NULL, $email = NULL) {
         $this->db->where('email', $email);
         return $this->db->replace('asiakas', $data);
     }
          
        
    /**
     * read user info from db
     * 
     * @param       string  $email   email address used
     * @return      boolean
     */
     public function get_info($email = NULL) {
         $this->db->from('asiakas');
         $this->db->where('email', $email);
         $query = $this->db->get();
         return $query->result();
     }
}