<nav class="sisunavbar navbar navbar-expand-md navbar-dark fixed-top bg-dark">
  <a class="navbar-brand" href="/">SISUCRATE &nbsp;<img src="/assets/img/logo.png" alt="logo" height="42" width="42"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarCollapse">
    <ul class="navbar-nav">
        
      <li class="nav-item">
        <a class="nav-link" href="/profile">Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/subscriptions">Subscriptions</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/crates">Crates</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/about">About</a>
      </li>
    </ul>
    <ul class="navbar-nav ml-auto">
    <?php
    if ($login) { ?>
    <a class="login">Logged in as <?php print $_SESSION['user_email'] ?></a>
      <li><a class="nav-link loglink" href="/logout">Logout</a></li>
    </ul>
    <?php } else { ?>
      <li><a class="nav-link loglink" href="/login">Login</a></li>
    </ul>
    <?php } ?>
  </div>
</nav>