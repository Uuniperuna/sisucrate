<div class="main col-md-9 ml-sm-auto col-lg-10 px-4">
  <?php echo validation_errors() ;?>
  <?php echo form_open('profile');?>
  
  <?php foreach($infos as $info){?>
  <h3>Your profile</h3>
  <div class="profile">
    <div class="row">
        <div class="form-group col">
          <label for="etunimi">First name</label>
          <input type="text" class="form-control" id="etunimi" name="etunimi" placeholder="First name" value="<?php echo $info->etunimi;?>" required>
        </div>
        <div class="form-group col">
          <label for="sukunimi">Last name</label>
          <input type="text" class="form-control" id="sukunimi" name="sukunimi" placeholder="Last name" value="<?php echo $info->sukunimi;?>" required>
        </div>
    </div>
    <div class="row">    
        <div class="form-group col">
          <label for="aspuh">Phone number</label>
          <input type="text" class="form-control" id="aspuh" name="aspuh" placeholder="Phone number" value="<?php echo $info->aspuh;?>">
          <small class="text-muted">Some shipping options require a phone number.</small>
        </div>
        <div class="form-group col">
          <label for="email">Email</label>
          <input type="text" class="form-control disabled" placeholder="Email" value="<?php echo $info->email;?>" >
          <small class="text-muted">We use your email to contact you. You can't change your email but you can create another account <a href="/register/">here</a></small>
        </div>
    </div>
    <div class="row">  
        <div class="form-group col">
          <label for="aspost">Address</label>
          <input type="text" class="form-control" id="aspost" name="aspost" placeholder="Address" value="<?php echo $info->aspost;?>">
          <small class="text-muted">Please note that you need to provide a proper address to get your Sisucrate&trade;.</small>
        </div>
        <div class="form-group col">
          <label for="postitmp">City</label>
          <input type="text" class="form-control" id="postitmp" name="postitmp" placeholder="City" value="<?php echo $info->postitmp;?>">
        </div>
    </div>
    <div class="row"> 
        <div class="form-group col">
          <label for="maakunta">Province / state</label>
          <input type="text" class="form-control" id="maakunta" name="maakunta" placeholder="Province / state" value="<?php echo $info->maakunta;?>">
        </div>
        <div class="form-group col">
          <label for="postinro">ZIP code / postal code</label>
          <input type="text" class="form-control" id="postinro" name="postinro" placeholder="ZIP code / postal code" value="<?php echo $info->postinro;?>">
        </div>
    </div>
    <div class="row"> 
      <div class="form-group">
          <button class="btn btn-success" type="submit">Submit changes&nbsp;<i class="fas fa-edit"></i></button>
          <button class="btn btn-dark" type="reset">Reset&nbsp;<i class="fas fa-redo-alt"></i></button>
      </div>    
    </div>
  </div>
  <?php }?> 
<?php echo form_close(); ?>
</div>