<div class="main centered">
  <h3>Register</h3>
  <?php echo validation_errors() ;?>
  <?php echo form_open('register'); ?>
  <div class="row">
    <div class="form-group col">
      <label for="email">Email</label>
      <input type="text" class="form-control" id="email" name="email" placeholder="User email" required>
      <small class="text-muted">We won't share your email with third parties, but we will steal your bike.</small>
    </div>
  </div>
  <div class="row">
    <div class="form-group col">
      <label for="password">Password</label>
      <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
    </div>
  </div>
  <div class="row"> 
    <div class="form-group">
        <button class="btn btn-success" type="submit">Register&nbsp;<i class="fas fa-user-plus"></i></button>
        <button class="btn btn-dark" type="reset">Reset&nbsp;<i class="fas fa-redo-alt"></i></button>
        <a href="/login/" class="btn btn-info">Login&nbsp;<i class="fas fa-sign-in-alt"></i></a>
    </div>
  </div>
  <?php echo form_close(); ?>
</div>

