<?php
if ($errordata='login') { ?>
    <div class="alert alert-danger" role="alert">Login failed. Check username and password.</div>
<?php } ?>