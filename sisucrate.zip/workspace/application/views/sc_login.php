<div class="main centered">
  <h3>Login</h3>
  <?php echo validation_errors() ;?>
  <?php echo form_open('login'); ?>
  <div class="row">
    <div class="form-group col">
      <label for="email">Email</label>
      <input type="text" class="form-control" id="email" name="email" placeholder="User email" required>
      <small class="text-muted">We won't share your email with third parties, but we will steal your bike.</small>
    </div>
  </div>
  <div class="row">
    <div class="form-group col">
      <label for="password">Password</label>
      <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
    </div>
  </div>
  <div class="row"> 
    <div class="form-group">
        <button class="btn btn-success" type="submit">Login&nbsp;<i class="fas fa-sign-in-alt"></i></button>
        <button class="btn btn-dark" type="reset">Reset&nbsp;<i class="fas fa-redo-alt"></i></button>
        <a href="/register/" class="btn btn-info">Register&nbsp;<i class="fas fa-user-plus"></i></a>
    </div>
  </div>
  <?php echo form_close(); ?>
</div>

