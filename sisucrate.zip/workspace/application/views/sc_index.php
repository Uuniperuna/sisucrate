<div class="main col-md-10 ml-sm-auto col-lg-12 px-4 bg-white">
    <video id="bgvid" playsinline autoplay muted>
        <source src="/assets/vid/sisucrate.webm" type="video/webm">
    </video>
    
    <div id="carouselIndicators" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
            <div class="crate">
                <img class="crate-item" src="/assets/img/crates/sc_placeholder.jpg" alt="Tammikuu">
                <span class="cratecaption">Tammikuu</span>
            </div>
            <div class="crate">
                <img class="crate-item" src="/assets/img/crates/sc_placeholder2.jpg" alt="Helmikuu">
                <span class="cratecaption">Helmikuu</span>
            </div>
            <div class="crate">   
                <img class="crate-item" src="/assets/img/crates/sc_placeholder.jpg" alt="Maaliskuu">
                <span class="cratecaption">Maaliskuu</span>
            </div>
          </div>
        <div class="carousel-item">
            <div class="crate">
                <img class="crate-item" src="/assets/img/crates/sc_placeholder.jpg" alt="Huhtikuu">
                <span class="cratecaption">Huhtikuu</span>
            </div>
            <div class="crate">
                <img class="crate-item" src="/assets/img/crates/sc_placeholder2.jpg" alt="Toukokuu">
                <span class="cratecaption">Toukokuu</span>
            </div>
            <div class="crate">   
                <img class="crate-item" src="/assets/img/crates/sc_placeholder.jpg" alt="Kesäkuu">
                <span class="cratecaption">Kesäkuu</span>
            </div>          
        </div>
        <div class="carousel-item">
            <div class="crate">
                <img class="crate-item" src="/assets/img/crates/sc_placeholder.jpg" alt="Heinäkuu">
                <span class="cratecaption">Heinäkuu</span>
            </div>
            <div class="crate">
                <img class="crate-item" src="/assets/img/crates/sc_placeholder2.jpg" alt="Elokuu">
                <span class="cratecaption">Elokuu</span>
            </div>
            <div class="crate">   
                <img class="crate-item" src="/assets/img/crates/sc_placeholder.jpg" alt="Syyskuu">
                <span class="cratecaption">Syyskuu</span>
            </div>
        </div>
        <div class="carousel-item">
            <div class="crate">
                <img class="crate-item" src="/assets/img/crates/sc_placeholder.jpg" alt="Lokakuu">
                <span class="cratecaption">Lokakuu</span>
            </div>
            <div class="crate">
                <img class="crate-item" src="/assets/img/crates/sc_placeholder2.jpg" alt="Marraskuu">
                <span class="cratecaption">Marraskuu</span>
            </div>
            <div class="crate">   
                <img class="crate-item" src="/assets/img/crates/sc_placeholder.jpg" alt="Joulukuu">
                <span class="cratecaption">Joulukuu</span>
            </div>
        </div>
      </div>
      
      <a class="carousel-control-prev" href="#carouselIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
      <ol class="carousel-indicators">
        <li data-target="#carouselIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselIndicators" data-slide-to="1"></li>
        <li data-target="#carouselIndicators" data-slide-to="2"></li>
        <li data-target="#carouselIndicators" data-slide-to="2"></li>
      </ol>      
    </div>    
</div>

