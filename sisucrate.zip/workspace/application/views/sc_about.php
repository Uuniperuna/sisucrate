    <link rel="stylesheet" href="/assets/css/jq.css">
<div class="main col-md-9 ml-sm-auto col-lg-12 px-4">
    <div class="bground">

</div><h2>About us...</h2>
<h1>what the crate?</h1>

<br>
<p> There are multiple different crates and boxes in the markets, but none like ours.<br> Through the ages, Finland has dared against great foes, ranging from wars and weather conditions, to hockey matches and high taxes.
Even against these great odds, Finland has prevailed. Our secret? Sisu. <br> <br>
We are convinced that the world needs more sisu, and our mission is to give it to them, anywhere in the world. <br>
What are you waiting for? Do you think you have what it takes to try the great salmiakki challenge, and grow more resilient?</p>
<h1>SOUMI KERPELE!!</h1>

<div class="coolpic"></div>

<br>
<section class="about">
<h1>Something about the creators...</h1>
<ul>
<li><h3>Henri Korpi</h3>
<p> A first year student at OAMK computing sciences. Ei.
</p></li> 

<li><h3>Jonne Norrbacka</h3>
<p> A first year student at OAMK computing sciences
</p></li> 

<li><h3>Jenna Qvickman</h3>
<p> Aspiring 3D game artist, retro game collector and a bad cosplayer, also a first year student at OAMK computing sciences
</p></li>

<li><h3>Riku Halmetoja</h3>
<p> A first year student at OAMK computing sciences
</p></li>

<li><h3>Petri Launimaa</h3>
<p> A first year student at OAMK computing sciences, the coding wizard and a part time catgirl.
</p></li>

<li><h3>Toni Miettinen</h3>
<p> A first year student at OAMK computing sciences
</p></li>
</ul>
</section>
<div class="coolpic2"></div>
</div>
</div>