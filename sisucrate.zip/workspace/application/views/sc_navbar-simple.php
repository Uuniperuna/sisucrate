<nav class="sisunavbar navbar navbar-expand-md navbar-dark fixed-top bg-dark">
  <a class="navbar-brand" href="/">SISUCRATE &nbsp;<img src="/assets/img/logo.png" alt="logo" height="42" width="42"></a>
</nav>