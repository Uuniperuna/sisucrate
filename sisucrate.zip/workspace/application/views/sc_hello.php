<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Kenraali Kenobi!</title>
	<link rel="stylesheet" href="/assets/css/style.css" type="text/css" />
</head>
<body>
    <div class="crate">
        <img src="<?php echo base_url();?>/assets/img/hello.gif">
    </div>
</body>
	